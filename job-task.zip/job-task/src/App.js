import "./App.css";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Card from "@material-ui/core/Card";
import IconButton from "@material-ui/core/IconButton";
import ReviewedIcon from "@material-ui/icons/Visibility";
import UnreviewedIcon from "@material-ui/icons/VisibilityOff";
import RemoveIcon from "@material-ui/icons/HighlightOff";
import CircularProgress from "@material-ui/core/CircularProgress";
import Tooltip from "@material-ui/core/Tooltip";
import React, { useEffect, useState } from "react";
import axios from "axios";
import moment from "moment";
function App() {
  const [apiData, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [color, setColor] = useState("burlywood");

  useEffect(() => {
    if (apiData.length === 0) {
      axios
        .get(
          "https://api-dev.insidetrak.interactive1.com/homepage/get-latest-images"
        )
        .then((response) => {
          var data = response.data.data.map((data) => {
            return {
              ...data,
              reviewedStatus: false,
            };
          });

          setLoading(false);
          setData(data);
        });
    }
  });

  return (
    <div className="App">
      <AppBar
        style={{
          backgroundColor: "white",
          color: "burlywood",
        }}
      >
        <Toolbar style={{ justifyContent: "center" }}>
          <h2>Preview photos ({apiData.length})</h2>
        </Toolbar>
      </AppBar>

      <div style={{ display: "inline-block", marginTop: 100 + "px" }}>
        {!loading ? (
          apiData.map((tile) => (
            <Card
              key={tile.id}
              style={{
                width: 260 + "px",
                height: 330 + "px",
                display: "inline-block",
                margin: 5,
              }}
            >
              <img src={tile.thumbnailUrls.imedia_300} alt={tile.title} />
              <div style={{ fontSize: 12, fontWeight: 600 }}>
                <div>{tile.title}</div>
                <div>Posted by: {tile.authorScreenName}</div>
                <div>{moment(tile.createdOn).format("LLL")}</div>
                <div>Description: {tile.description}</div>
              </div>
              <IconButton
                onClick={() => {
                  const index = apiData.findIndex((data) => data.id == tile.id);
                  let newData = [...apiData];
                  newData[index] = {
                    ...newData[index],
                    reviewedStatus: true,
                  };
                  setData(newData);
                }}
                style={{ color: tile.reviewedStatus ? "burlywood" : "grey" }}
              >
                <ReviewedIcon />
              </IconButton>
              <IconButton
                onClick={() => {
                  const index = apiData.findIndex((data) => data.id == tile.id);
                  let newData = [...apiData];
                  newData[index] = {
                    ...newData[index],
                    reviewedStatus: false,
                  };
                  setData(newData);
                }}
                style={{ color: !tile.reviewedStatus ? "burlywood" : "grey" }}
              >
                <UnreviewedIcon />
              </IconButton>

              <IconButton
                onClick={() => {
                  setData(apiData.filter((picture) => picture.id !== tile.id));
                }}
              >
                <RemoveIcon />
              </IconButton>
              <span>{tile.reviewedStatus ? "Reviewed" : "Unreviewed"}</span>
            </Card>
          ))
        ) : (
          <CircularProgress style={{ color: "white" }} size={40} />
        )}
      </div>
    </div>
  );
}

export default App;
